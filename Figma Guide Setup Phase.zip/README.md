
  # Figma Guide Setup Phase

  This is a code bundle for Figma Guide Setup Phase. The original project is available at https://www.figma.com/design/5GexRHo7WtF0QWEa1NggSJ/Figma-Guide-Setup-Phase.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  